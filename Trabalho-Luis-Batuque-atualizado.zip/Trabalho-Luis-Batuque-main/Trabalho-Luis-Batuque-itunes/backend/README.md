# Batuque — Back-end

API em **Node.js + Express + SQLite** (`better-sqlite3`). Sem banco para instalar: o arquivo `data/batuque.db` é criado sozinho.

## Rodar
```
cd backend
npm install
npm start          # http://localhost:3000  (também serve o front)
```
Variáveis opcionais (ver `.env.example`): `PORT`, `JWT_SECRET` (**troque em produção**), `JWT_EXPIRES_IN`, `DB_FILE`.
Exemplo no PowerShell: `$env:JWT_SECRET="um-texto-longo-e-aleatorio"; npm start`

## Rotas
| Método | Rota | O que faz |
|---|---|---|
| GET | `/api/health` | Verifica se o servidor está no ar |
| POST | `/api/auth/register` | `{nome, email, senha}` → cria a conta, devolve `{token, user}` |
| POST | `/api/auth/login` | `{email, senha}` → `{token, user}` |
| GET | `/api/auth/me` | Dados da conta logada (Bearer token) |
| DELETE | `/api/auth/me` | Apaga a conta e todos os dados |
| GET | `/api/data` | Todos os dados do usuário (biblioteca, resenhas, notas, favoritos...) |
| PUT | `/api/data` | `{mudancas: {chave: valor}}` → grava só o que mudou |

Rotas protegidas usam o cabeçalho `Authorization: Bearer <token>`.

## Banco (SQLite)
- `users` (id, nome, email único, senha_hash, criado_em)
- `user_data` (user_id, chave, valor JSON, atualizado_em) — uma linha por chave do estado do front

## Segurança
Senha com `bcrypt` (nunca em texto puro) · JWT com validade · mesma mensagem para e-mail inexistente e senha errada · limite de 20 tentativas/15 min por IP nas rotas de login e cadastro · só chaves permitidas em `/api/data`, até 1 MB cada · `helmet` ativo.

## Como o front se conecta
`batuque/js/api.js` envia ao servidor, alguns instantes após cada alteração, só as chaves que mudaram. Se o servidor cair, o app segue no `localStorage` e reenvia quando voltar. Conflito: vale a última edição de cada chave.
