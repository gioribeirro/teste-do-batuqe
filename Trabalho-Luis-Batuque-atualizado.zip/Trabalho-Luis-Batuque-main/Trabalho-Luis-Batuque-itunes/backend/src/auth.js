const jwt = require("jsonwebtoken");

const SECRET = process.env.JWT_SECRET || "dev-secret-nao-use-em-producao";
if (!process.env.JWT_SECRET) console.warn("[aviso] JWT_SECRET não definido; usando segredo de desenvolvimento.");

function sign(user) {
  return jwt.sign({ sub: user.id }, SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || "7d" });
}

/* Exige "Authorization: Bearer <token>" e preenche req.userId */
function requireAuth(req, res, next) {
  const h = req.headers.authorization || "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : null;
  if (!token) return res.status(401).json({ erro: "Não autenticado." });
  try {
    req.userId = jwt.verify(token, SECRET).sub;
    next();
  } catch (e) {
    res.status(401).json({ erro: "Sessão expirada. Entre novamente." });
  }
}

module.exports = { sign, requireAuth };
