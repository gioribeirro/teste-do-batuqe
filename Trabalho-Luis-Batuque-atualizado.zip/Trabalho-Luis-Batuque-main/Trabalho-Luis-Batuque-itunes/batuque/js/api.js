/* Batuque — cliente da API + sincronização com o backend.
   O servidor é OPCIONAL: se ele estiver desligado, o app continua funcionando 100% no navegador (localStorage). */
(function (B) {
  var TK = "batuque:token", UK = "batuque:uid", SK = "batuque:sync";
  var local = /^(localhost|127\.0\.0\.1)$/.test(location.hostname);
  /* Aberto por file:// ou por outro servidor local (ex.: Live Server) -> fala com o backend na porta 3000 */
  var BASE = window.BATUQUE_API || ((location.protocol === "file:" || (local && location.port !== "3000")) ? "http://localhost:3000" : "");
  var KEYS = ["theme", "accent", "inheritCover", "density", "listening", "libFields", "saved", "favAlbums", "favTracks",
    "albumRatings", "trackRatings", "reviews", "savedReviews", "draft", "profile", "volume", "queue", "trackNotes",
    "replay", "playlistTracks", "playlistMeta", "playlistToggles", "pageColor", "following", "artistRatings",
    "artistDrafts", "plays", "privacy", "onboarded", "activity", "visited"];
  var LABEL = { guest: "Sem conta: dados só neste navegador", syncing: "Sincronizando…", ok: "Dados sincronizados", off: "Servidor indisponível: salvo só neste navegador" };

  function ls(k, v) {
    try { if (v === undefined) return localStorage.getItem(k); if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) {}
    return null;
  }
  function hash(s) { var h = 5381, i = s.length; while (i) h = (h * 33) ^ s.charCodeAt(--i); return (h >>> 0).toString(36) + ":" + s.length; }
  var synced; try { synced = JSON.parse(ls(SK) || "{}"); } catch (e) { synced = {}; }
  function saveSynced() { ls(SK, JSON.stringify(synced)); }

  /* ---------- HTTP ---------- */
  function request(method, path, body) {
    var h = { "Content-Type": "application/json" }, t = ls(TK);
    if (t) h.Authorization = "Bearer " + t;
    return fetch(BASE + "/api" + path, { method: method, headers: h, body: body === undefined ? undefined : JSON.stringify(body) })
      .catch(function () { var e = new Error("Servidor indisponível."); e.offline = true; throw e; })
      .then(function (r) {
        if (r.status === 204) return null;
        return r.json().catch(function () { return {}; }).then(function (j) {
          if (!r.ok) { var e = new Error(j.erro || "Erro " + r.status); e.status = r.status; e.campos = j.campos; throw e; }
          return j;
        });
      });
  }

  B.api = {
    base: BASE, request: request,
    hasToken: function () { return !!ls(TK); },
    uid: function () { return ls(UK); },
    setAuth: function (token, uid) { ls(TK, token); ls(UK, String(uid)); },
    clearToken: function () { ls(TK, null); },
    resetSynced: function () { synced = {}; saveSynced(); }
  };

  /* ---------- Sincronização ---------- */
  var timer = null, inflight = false;
  function setStatus(s) {
    var el = document.getElementById("syncDot");
    if (el) { el.dataset.sync = s; el.title = LABEL[s]; el.setAttribute("aria-label", LABEL[s]); }
  }
  function dirtyKeys() {
    var st = B.store.state;
    return KEYS.filter(function (k) { return st[k] !== undefined && hash(JSON.stringify(st[k])) !== synced[k]; });
  }
  function onFail(e) {
    if (e.status === 401) { B.api.clearToken(); setStatus("guest"); if (B.ui) B.ui.toast("Sessão expirada. Entre de novo para sincronizar.", "soft"); return; }
    setStatus("off");
    clearTimeout(timer); timer = setTimeout(schedule, 15000);       // tenta de novo mais tarde
  }
  function schedule() {
    if (!B.api.hasToken()) return;
    clearTimeout(timer); timer = setTimeout(push, 700);              // agrupa várias alterações seguidas
  }
  function push() {
    if (!B.api.hasToken()) { setStatus("guest"); return Promise.resolve(); }
    if (inflight) { schedule(); return Promise.resolve(); }
    var keys = dirtyKeys();
    if (!keys.length) { setStatus("ok"); return Promise.resolve(); }
    var m = {}, hs = {};
    keys.forEach(function (k) { m[k] = B.store.state[k]; hs[k] = hash(JSON.stringify(m[k])); });
    inflight = true; setStatus("syncing");
    return request("PUT", "/data", { mudancas: m }).then(function () {
      keys.forEach(function (k) { synced[k] = hs[k]; });
      saveSynced(); inflight = false;
      if (dirtyKeys().length) { setStatus("syncing"); schedule(); } else setStatus("ok");
    }, function (e) { inflight = false; onFail(e); });
  }
  /* Baixa os dados da conta. force=true (login): o servidor vence. Sem force: só substitui o que não foi editado aqui. */
  function pull(force) {
    if (!B.api.hasToken()) { setStatus("guest"); return Promise.resolve(false); }
    setStatus("syncing");
    return request("GET", "/data").then(function (res) {
      var st = B.store.state, d = res.dados || {}, changed = false;
      Object.keys(d).forEach(function (k) {
        if (KEYS.indexOf(k) < 0) return;
        var sj = JSON.stringify(d[k]), lj = JSON.stringify(st[k]);
        if (sj === lj) { synced[k] = hash(sj); return; }
        if (force || hash(lj) === synced[k]) { st[k] = d[k]; synced[k] = hash(sj); changed = true; }
        /* senão: houve edição local sem conexão; a versão local vence e é enviada abaixo */
      });
      saveSynced();
      if (changed) B.store.save(true);                               // grava no navegador sem disparar envio
      setStatus("ok"); schedule();                                   // envia o que só existe aqui
      return changed;
    }, function (e) { onFail(e); return false; });
  }

  B.sync = { schedule: schedule, push: push, pull: pull };

  window.addEventListener("online", schedule);
  document.addEventListener("DOMContentLoaded", function () {
    if (!B.api.hasToken()) { setStatus("guest"); return; }
    pull(false).then(function (changed) {
      var key = "batuque:reloaded";                                  // recarrega uma única vez para aplicar tema, fila etc.
      if (changed && !sessionStorage.getItem(key)) { try { sessionStorage.setItem(key, "1"); } catch (e) {} location.reload(); }
      else { try { sessionStorage.removeItem(key); } catch (e) {} }
    });
  });
})(window.Batuque);
